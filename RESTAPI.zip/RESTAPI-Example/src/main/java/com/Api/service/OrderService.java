package com.Api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Transactional
    public OrderDTO createOrder(OrderDTO orderDTO) {
        // Business logic for creating an order
    }
    
    // Other methods for order management
}
