package com.Api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
